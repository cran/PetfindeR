library(testthat)
library(PetfindeR)

test_check('PetfindeR')